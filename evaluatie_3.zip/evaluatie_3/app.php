<?php
// LINK HIER ALL CONTROLLERS EN MODELS
// ZO HEB JE TOEGANG TOT ALLE FUNCTIES ALS JE DIT BESTAND INCLUDE
include_once 'config.php';

include_once 'Models/Model.php';

include_once 'Controllers/displayMovies.php';

