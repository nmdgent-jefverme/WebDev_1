<h2 class="indigo-text text-darken-1"><?php echo $dates[0]['name'] ?></h2>
<p><?php echo $dates[0]['description'] ?></p>