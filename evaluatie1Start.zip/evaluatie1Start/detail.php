<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Webdev I Evaluatie 1</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<section>
    <h1>DEMO</h1>
    <img src="images/default.jpg">
    <div class="content">
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Officia doloribus nulla illum non modi explicabo veritatis eveniet dicta laborum soluta debitis facere sunt quas reiciendis, pariatur hic autem dignissimos! Illo!</p>
        <a href="#">Bewerk</a>
    </div>    
    <a href="index.php" class="btn">Keer terug</a>
</section>
</body>
</html>
