<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Webdev I Evaluatie 1</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<section>
    <h1>Bericht toevoegen</h1>    
    <form>
        <label>
            Titel<br>
            <input type="text" name="title" required>
        </label>
        <label>
            Foto<br>
            <input type="file" name="photo" value="Kies...">
        </label>
        <label>
            Inhoud<br>
            <textarea name="content" rows="15"></textarea>
        </label>
        <button type="submit" name="submit">Toevoegen</button>
        <a href="index.php" class="btn">Keer terug</a>

    </form>

</section>
</body>
</html>
