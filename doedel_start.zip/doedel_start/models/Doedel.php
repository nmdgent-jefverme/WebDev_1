<?php

class Doedel {


    public function __construct() {
        
    }

    public static function byId($code){
        
    }


    public static function get_results($doedel_code){
        
    }

    public static function add_votes($doedel_code, $name, $email, $dates) {
        
        
    }

    public static function add($name, $description, $dates){
        global $db;

        $sql = "INSERT INTO doedel 
        (doedel_code, name, description, creation_date) VALUES 
        (:doedel_code, :name, :description, :creation_date)";
    
        $doedel_code  = uniqid();

        $sth = $db->prepare($sql);
        $sth->execute([
            ':name' => $name,
            ':description' => $description,
            ':doedel_code' => $doedel_code,
            ':creation_date' => date("Y-m-d H:i:s")
        ]);
        
        foreach($dates as $date) {
            $sql = "INSERT INTO doedel_date 
            (doedel_code, doedel_date) VALUES 
            (:doedel_code, :doedel_date)";

            $sth = $db->prepare($sql);
            $sth->execute([
                ':doedel_code' => $doedel_code,
                ':doedel_date' => date('Y-m-d H:i:s', strtotime($date))
            ]);
        }

        return $doedel_code;
    }

}