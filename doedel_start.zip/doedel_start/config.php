<?php

CONST BASE_URL = '/week11';

CONST DB_DSN = 'mysql:dbname=Doedel;host=127.0.0.1;port=3306';
CONST DB_USER = 'root';
CONST DB_PWD = 'secret';

