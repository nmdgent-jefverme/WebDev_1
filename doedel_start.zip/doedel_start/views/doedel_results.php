<h2 class="indigo-text text-darken-1">Doedel</h2>
<p>omschrijving</p>
        
<div class="collection">
    
    <div class="collection-item">
            
        <span class="new badge" data-badge-caption="votes">1</span>
        Thursday, 12 Dec 2019 00:12    
    </div>

    <div class="collection-item">
            
        <span class="new badge" data-badge-caption="votes">1</span>
        Thursday, 12 Dec 2019 00:12    
    </div>

</div>