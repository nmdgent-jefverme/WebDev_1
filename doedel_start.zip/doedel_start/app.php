<?php

//Const maken waarin het volledige pad naar het project zit
define('BASE_PATH', dirname(__FILE__));


require_once BASE_PATH . '/config.php';
require_once BASE_PATH . '/includes/db.php';


require_once BASE_PATH . '/models/Doedel.php';
